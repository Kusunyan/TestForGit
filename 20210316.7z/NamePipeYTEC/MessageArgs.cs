﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace NamePipeYTEC
{
    //因為只能傳遞實體物件，所以不能用Interface，也不能用Object，一定要明確的類型，否則會無法序列化資料
    [DataContract]
    public class FlowPreMessageArgs:IWCFFlowPreArgs
    {
        [DataMember]
        public string PlanName { get; set; }
        [DataMember]
        public int PlanIndex { get; set; }
        [DataMember]
        public string SiteSequence { get; set; }
        [DataMember]
        public string GoThrough { get; set; }
        [DataMember]
        public string DisableByMarkNo { get; set; }
        [DataMember]
        public string EnableByMarkNo { get; set; }
        [DataMember]
        public string Remark { get; set; }
        [DataMember]
        public string PowerDownPlan { get; set; }
    }

    [DataContract]
    public class FlowConditionMessageArgs:IWCFFlowConditionArgs
    {
        [DataMember]
        public string PlanName { get; set; }
        [DataMember]
        public int PlanIndex { get; set; }
        [DataMember]
        public List<String> planCollection { get; set; }
        [DataMember]
        public string PassLoopCount { get; set; }
        [DataMember]
        public string PassRejectBin { get; set; }
        [DataMember]
        public string PassSortTable { get; set; }
        [DataMember]
        public string PassMarkNo { get; set; }
        [DataMember]
        public string PassBranch { get; set; }

        [DataMember]
        public string FailLoopCount { get; set; }
        [DataMember]
        public string FailRejectBin { get; set; }
        [DataMember]
        public string FailSortTable { get; set; }
        [DataMember]
        public string FailMarkNo { get; set; }
        [DataMember]
        public string FailBranch { get; set; }

        [DataMember]
        public string UnconLoopCount { get; set; }
        [DataMember]
        public string UnconRejectBin { get; set; }
        [DataMember]
        public string UnconSortTable { get; set; }
        [DataMember]
        public string UnconMarkNo { get; set; }
        [DataMember]
        public string UnconBranch { get; set; }
    }

    [DataContract]
    public class KernalUpdateValMessageArgs 
    {
        [DataMember]
        public string m_CtrlAction { get; set; }
        [DataMember]
        public string m_szPlanName { get; set; }
        [DataMember]
        public string m_szFieldName { get; set; }
        [DataMember]
        public int m_iDrvSN { get; set; }
        [DataMember]
        public string m_szValue { get; set; }
        [DataMember]
        public int m_iValue { get; set; }
        [DataMember]
        public double m_dValue { get; set; }
        [DataMember]
        public List<int> m_AiUnOrderedParamSeq=new List<int>();
    }

    [DataContract]
    public class WindowMessageArgs:IWCFWindowArgs
    {
        [DataMember]
        public string MessageType { get; set; }

        [DataMember]
        public int PageIndex { get; set; }
       
        [DataMember]
        public int LocationX { get; set; }
        [DataMember]
        public int LocationY { get; set; }
        [DataMember]
        public int Width { get; set; }
        [DataMember]
        public int Height { get; set; }
    }
}
