﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
  [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
  public class DuplexServer : IDuplexServiceMessage, IDisposable
  {
    private static DuplexServer instance = null;
    private object _lockObject;
    ServiceHost _serverHost;
    List<string> _registeredClients = new List<string>();
    static Dictionary<IDuplexCallbackMessage, string> _clientCallBackService = new Dictionary<IDuplexCallbackMessage, string>();
    //private static List<IFromServerToClientMessage> _subscribers = new List<IFromServerToClientMessage>();
    private Action<string, string, object> DataReady;
    public event Action<string, string, object> ClientDataIsReady
    {
      add
      {
        DataReady += value;
      }
      remove
      {
        DataReady -= value;
      }
    }
    public void HostOff()
    {
      if (_serverHost != null)
        if (_serverHost.State != CommunicationState.Closed)
        {
          foreach (var id in _clientCallBackService.Values)
          {
            try
            {         
              PostMessageToClient(id, "ShutDown", null);
            }
            catch (Exception ex)
            {
              string errorMsg = ex.Message;
            }
           
          }        
          _serverHost.Close();
        }
    }
    public void OpenHost()
    {
      InitailChainOfCommand(out FirstCommand);
      _serverHost = new ServiceHost(this);
      //Stack Overflow
      //My experience is that, when using NetNamedPipes, the "ReceiveTimout" on the binding functions like an "Inactivity Timeout" rather than a receive timout.Note that this different than how a NetTCPBinding works.
      var binding = new NetNamedPipeBinding();
      binding.ReceiveTimeout = TimeSpan.MaxValue; //new TimeSpan(0, 0, 20);//TimeSpan.MaxValue;

      binding.MaxBufferSize = 64 * 1024 * 64*64;
      binding.MaxReceivedMessageSize = 64 * 1024 *64*64;
      binding.MaxBufferPoolSize = 512 * 1024 * 4;
      //binding.SendTimeout = new TimeSpan(0, 0, 60);
      _serverHost.AddServiceEndpoint((typeof(IDuplexServiceMessage)), binding, "net.pipe://localhost/YTECDuplexServer");
      _serverHost.Faulted += new EventHandler(Host_Faulted);
      //_serverHost = new ServiceHost(typeof(Server));
      //_serverHost.AddServiceEndpoint((typeof(IFromClientToServerMessage)), new NetNamedPipeBinding(), "net.pipe://localhost/YTECServer");
      _serverHost.Open();
    }
    private DuplexServer()
    {
      _lockObject = new object();
    }

    private void Host_Faulted(object sender, EventArgs e)
    {
      throw new NotImplementedException();
    }

    //private void OpenDuplexChannel()
    //{
    //    _serverHost.Open();
    //}

    public static DuplexServer GetInstance
    {
      get
      {
        if (instance == null)
          instance = new DuplexServer();
        return instance;
      }
    }

    private ChainOfServerCommand<IDuplexCallbackMessage> FirstCommand = null;
    private void InitailChainOfCommand(out ChainOfServerCommand<IDuplexCallbackMessage> cosc)
    {
      ChainOfServerCommand<IDuplexCallbackMessage> scdpg = new ServerCommandDuplexPinGroup();
      ChainOfServerCommand<IDuplexCallbackMessage> scddi = new ServerCommandDuplexDrivenInfo();
      ChainOfServerCommand<IDuplexCallbackMessage> scdsii = new ServerCommandDuplexShmooIniInfo();
      ChainOfServerCommand<IDuplexCallbackMessage> scdspi = new ServerCommandDuplexShmooPlanInfo();
      ChainOfServerCommand<IDuplexCallbackMessage> scdssi = new ServerCommandDuplexShmooSiteInfo();
      ChainOfServerCommand<IDuplexCallbackMessage> scdspgt = new ServerCommandDuplexShmooPinGroupTable();
      ChainOfServerCommand<IDuplexCallbackMessage> scdspfr = new ServerCommandDuplexShmooPFResult();
      ChainOfServerCommand<IDuplexCallbackMessage> scdlad = new ServerCommandDuplexLAData();
      ChainOfServerCommand<IDuplexCallbackMessage> scdlat = new ServerCommandDuplexLATiming();
      ChainOfServerCommand<IDuplexCallbackMessage> scdcd = new ServerCommandDuplexCollectionData();
      ChainOfServerCommand<IDuplexCallbackMessage> scdnm = new ServerCommandDuplexNormalMessage();

      scdpg.NextCommand = scddi;
      scddi.NextCommand = scdsii;
      scdsii.NextCommand = scdspi;
      scdspi.NextCommand = scdssi;
      scdssi.NextCommand = scdspgt;
      scdspgt.NextCommand = scdspfr;
      scdspfr.NextCommand = scdlad;
      scdlad.NextCommand = scdlat;
      scdlat.NextCommand = scdcd;
      scdcd.NextCommand= scdnm;

      cosc = scdpg;
    }

    //public void HostOff() {
    //  if (_serverHost != null)
    //    if (_serverHost.State != CommunicationState.Closed)
    //      _serverHost.Close();
    //}
    //public static Server GetInstance {
    //  get {
    //    if (instance == null)
    //      instance = new Server();
    //    return instance;
    //  }
    //}


    public void PostMessageToClient(string clientName, string msgID, Object data)
    {
      lock (_lockObject)
      {
        if (_clientCallBackService.Values.Contains(clientName))
        {
          //IFromServerToClientMessage callback = OperationContext.Current.GetCallbackChannel<IFromServerToClientMessage>();
          //string senderName = _clientCallBackService[callback];
          var serve = _clientCallBackService.Where(p => 
          p.Value == clientName
          ).First();

          FirstCommand.Execute(serve.Key, msgID, data);

          //serve.Key.EXE(data);
        }
      }
    
    }

    public void SubScribe(string clientID)
    {
      lock (_lockObject)
      {
        IDuplexCallbackMessage callback = OperationContext.Current.GetCallbackChannel<IDuplexCallbackMessage>();
        if (_clientCallBackService.Values.Contains(clientID))
        {
          _clientCallBackService.Remove(_clientCallBackService.Single(p => p.Value == clientID).Key);
        }
        _clientCallBackService.Add(callback, clientID);
      }  
      //    if (!_registeredClients.Contains(clientID))
      //_registeredClients.Add(clientID);
    }

    public void PostMessage(string clientID, string msgID, object msg)
    {
      DataReady?.Invoke(clientID, msgID, msg);
    }

    public void Dispose()
    {
      // _clientCallBackService.
    }

    public void UnSubScribe(string clientID)
    {
      IDuplexCallbackMessage callback = OperationContext.Current.GetCallbackChannel<IDuplexCallbackMessage>();
      if (_clientCallBackService.Keys.Contains(callback) == false)
      {
        throw new InvalidOperationException("Cannot find callback");
      }
      else
      {
        _clientCallBackService.Remove(callback);
      }
      //if (_registeredClients.Contains(clientID))
      //    _registeredClients.Remove(clientID);
    }
    public void PostFlowPreMessage(string clientID, string msgID, FlowPreMessageArgs data)
    {
      DataReady?.Invoke(clientID, msgID, data);
    }
    public void PostFlowConditionMessage(string clientID, string msgID, FlowConditionMessageArgs data)
    {
      DataReady?.Invoke(clientID, msgID, data);
    }

    public void PostKenralUpdateValMessage(string clientID, string msgID, KernalUpdateValMessageArgs data)
    {
      DataReady?.Invoke(clientID, msgID, data);
    }

    public void PostDrivenInfoMessage(string clientID, string msgID, DriverInfoMessageArgs data)
    {
      DataReady?.Invoke(clientID, msgID, data);
    }

    public void PostDebugToolDumpPatternMessage(string clientID, string msgID, DebugToolDumpPatternMessageArgs data)
    {
      DataReady?.Invoke(clientID, msgID, data);
    }

    public void PostCollectionMessage(string clientID, string msgID, List<object> msg)
    {
      DataReady?.Invoke(clientID, msgID, msg);
    }
  }
}
