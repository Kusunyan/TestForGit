﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;


namespace NamePipeYTEC
{
  [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Reentrant, InstanceContextMode = InstanceContextMode.Single)]
  public class Client : IFromServerToClientMessage, IDisposable
  {
    ServiceHost _clientHost;

    protected Action<string, object> DataReady;
    public event Action<string, object> ServerDataIsReady {
      add {
        DataReady += value;
      }
      remove {
        DataReady -= value;
      }
    }

    private string _clientID = "";
    public Client(string clientName) {
      _clientHost = new ServiceHost(this);

      NetNamedPipeBinding binding = new NetNamedPipeBinding();
      binding.MaxBufferSize = 64 * 1024 * 4;
      binding.MaxReceivedMessageSize = 64 * 1024 * 4;
      binding.MaxBufferPoolSize = 512 * 1024 * 4;
      _clientHost.AddServiceEndpoint((typeof(IFromServerToClientMessage)), binding, $"net.pipe://localhost/YTEC_{clientName}");
      //_clientHost.AddServiceEndpoint((typeof(IFromServerToClientMessage)), new NetNamedPipeBinding(), $"net.pipe://localhost/YTEC_{clientName}");
      _clientHost.Open();
      _clientID = clientName;
      Register(_clientID);
      InitailChainOfClienCommand(out FirstCommand);
    }

    private ChainOfClientCommand<IFromClientToServerMessage> FirstCommand = null;
    private void InitailChainOfClienCommand(out ChainOfClientCommand<IFromClientToServerMessage> firstCommand) {
      ChainOfClientCommand<IFromClientToServerMessage> ccfp = new ClientCommandFlowPre();
      ChainOfClientCommand<IFromClientToServerMessage> ccfc = new ClientCommandFlowCondition();
      ChainOfClientCommand<IFromClientToServerMessage> cckuv = new ClientCommandKernalUpdateVal();
      ChainOfClientCommand<IFromClientToServerMessage> ccrdi = new ClientCommandReplaceDrivenInfo();
      ChainOfClientCommand<IFromClientToServerMessage> ccdtdla = new ClientCommandDebugToolDumpLa();
      ChainOfClientCommand<IFromClientToServerMessage> ccdtdcp = new ClientCommandDebugToolDumpCapture();
      ChainOfClientCommand<IFromClientToServerMessage> ccdtdps = new ClientCommandDebugToolDumpPtnSet();
      ChainOfClientCommand<IFromClientToServerMessage> ccdtdts = new ClientCommandDebugToolDumpTimSet();
      ChainOfClientCommand<IFromClientToServerMessage> ccdtdal = new ClientCommandDebugToolDumpAcLog();
      ChainOfClientCommand<IFromClientToServerMessage> ccnm = new ClientCommandNormalMessage();
      ccfp.NextCommand = ccfc;
      ccfc.NextCommand = cckuv;
      cckuv.NextCommand = ccrdi;
      ccrdi.NextCommand = ccdtdla;
      ccdtdla.NextCommand = ccdtdcp;
      ccdtdcp.NextCommand = ccdtdps;
      ccdtdps.NextCommand = ccdtdts;
      ccdtdts.NextCommand = ccdtdal;
      ccdtdal.NextCommand = ccnm;
      firstCommand = ccfp;
    }

    private void HostOff() {
      if (_clientHost != null) {
        if (_clientHost.State != CommunicationState.Closed) {
          try {
            _clientHost.Close();
          }
          catch (CommunicationException ex) {
            throw ex;
          }
        }
      }
    }

    private void Register(string clientID) {
      using (ChannelFactory<IFromClientToServerMessage> factory = new ChannelFactory<IFromClientToServerMessage>(new NetNamedPipeBinding(), new EndpointAddress("net.pipe://localhost/YTECServer"))) {        
        IFromClientToServerMessage clientToServerChannel = factory.CreateChannel();
        try {
          clientToServerChannel.Register(clientID);
        }
        catch (CommunicationException ex) {
          HostOff();
          throw ex;
        }
        finally {
          CloseChannel((ICommunicationObject)clientToServerChannel);
        }
      }
    }

    private void UnRegister(string clientID) {
      using (ChannelFactory<IFromClientToServerMessage> factory = new ChannelFactory<IFromClientToServerMessage>(new NetNamedPipeBinding(), new EndpointAddress("net.pipe://localhost/YTECServer"))) {
        IFromClientToServerMessage clientToServerChannel = factory.CreateChannel();
        try {
          clientToServerChannel.UnRegister(clientID);
        }
        catch (CommunicationException ex) {
          HostOff();
          throw ex;
        }
        finally {
          CloseChannel((ICommunicationObject)clientToServerChannel);
        }
      }
    }


    public void SendMessageToServer(string msgID, object data) {
      using (ChannelFactory<IFromClientToServerMessage> factory = new ChannelFactory<IFromClientToServerMessage>(new NetNamedPipeBinding(), new EndpointAddress("net.pipe://localhost/YTECServer"))) {
        IFromClientToServerMessage clientToServerChannel = factory.CreateChannel();
        try {
          FirstCommand.Execute(clientToServerChannel, this._clientID, msgID, data);

        }
        catch (CommunicationException ex) {
          throw ex;
        }
        finally {
          CloseChannel((ICommunicationObject)clientToServerChannel);
        }
      }
    }
    public void SendMessage(string msgID, object data) {
      DataReady?.Invoke(msgID, data);
    }


    private void CloseChannel(ICommunicationObject channel) {
      try {
        channel.Close();
      }
      catch (CommunicationException ex) {
        throw ex;
      }
      finally {
        channel.Abort();
      }
    }

    public void Dispose() {
      UnRegister(_clientID);
      this.HostOff();
    }

    public virtual void SendFlowPreMessage(string msgID, FlowPreMessageArgs data) {
      DataReady?.Invoke(msgID, data);
    }
    public virtual void SendFlowConditionMessage(string msgID, FlowConditionMessageArgs data) {
      DataReady?.Invoke(msgID, data);
    }

    public virtual void SendWindowMessage(string msgID, WindowMessageArgs data) {
      DataReady?.Invoke(msgID, data);
    }
    public virtual void SendTimingMessage(string msgID, TimingMessageArgs data) {
      DataReady?.Invoke(msgID, data);
    }
    public virtual void SendPinGroupMessage(string msgID, IOPinGroupMessageArgs data) {
      DataReady?.Invoke(msgID, data);
    }
    public virtual void SendPinMessage(string msgID, IOPinMessageArgs data) {
      DataReady?.Invoke(msgID, data);
    }
    public virtual void SendUserRelayGroupMessage(string msgID, UserRelayGroupMessageArgs data) {
      DataReady?.Invoke(msgID, data);
    }
    public virtual void SendUserRelayMessage(string msgID, UserRelayMessageArgs data) {
      DataReady?.Invoke(msgID, data);
    }
    public virtual void SendDrivenInfoMessage(string msgID, DriverInfoMessageArgs data) {
      DataReady?.Invoke(msgID, data);
    }
    public void SendPatternLabelListMessage(string msgID, DebugToolTestPgInfofoMessageArgs data) {
      DataReady?.Invoke(msgID, data);
    }
    public void SendDebugToolDumpPatternMessage(string msgID, DebugToolDumpPatternMessageArgs data) {
      DataReady?.Invoke(msgID, data);
    }
    public void SendDebugToolDumpTimingMessage(string msgID, DebugToolDumpTimingMessageArgs data) {
      DataReady?.Invoke(msgID, data);
    }
    public void SendDebugToolDumpAcLogMessage(string msgID, DebugToolDumpAcLogMessageArgs data) {
      DataReady?.Invoke(msgID, data);
    }
    public void SendDebugToolDumpLaMessage(string msgID, DebugToolDumpLaMessageArgs data) {
      DataReady?.Invoke(msgID, data);
    }
    public void SendDebugToolDumpCaptureMessage(string msgID, DebugToolDumpCaptureMessageArgs data) {
      DataReady?.Invoke(msgID, data);
    }
    public virtual void SendShmooIniInfoMessage(string msg, ShmooIniInfoMessageArgs data) {
      DataReady?.Invoke(msg, data);
    }

    public virtual void SendShmooPlanInfoMessage(string msg, ShmooPlanInfoMessageArgs data) {
      DataReady?.Invoke(msg, data);
    }

    public virtual void SendShmooSiteInfoMessage(string msg, ShmooSiteInfoMessageArgs data) {
      DataReady?.Invoke(msg, data);
    }

    public virtual void SendShmooPinGroupTableMessage(string msg, ShmooPinGroupTableMessageArgs data) {
      DataReady?.Invoke(msg, data);
    }
    public virtual void SendShmooPFResultMessage(string msg, ShmooPFResultMessageArgs data) {
      DataReady?.Invoke(msg, data);
    }
  }
}
