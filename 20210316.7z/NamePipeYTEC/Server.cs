﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{

  [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Reentrant, InstanceContextMode = InstanceContextMode.Single)]
  public class Server : IFromClientToServerMessage, IDisposable
  {
    private static Server instance = null;
    ServiceHost _serverHost;
    List<string> _registeredClients = new List<string>();
    private Action<string, string, object> DataReady;
    public event Action<string, string, object> ClientDataIsReady {
      add {
        DataReady += value;
      }
      remove {
        DataReady -= value;
      }
    }
    private Server() {

    }
    public void OpenHost() {
      _serverHost = new ServiceHost(this);

      NetNamedPipeBinding binding = new NetNamedPipeBinding();
      binding.MaxBufferSize = 64 * 1024 * 4;
      binding.MaxReceivedMessageSize = 64 * 1024 * 4;
      binding.MaxBufferPoolSize = 512 * 1024 * 4;
      _serverHost.AddServiceEndpoint((typeof(IFromClientToServerMessage)), binding, "net.pipe://localhost/YTECServer");
      //_serverHost.AddServiceEndpoint((typeof(IFromClientToServerMessage)), new NetNamedPipeBinding(), "net.pipe://localhost/YTECServer");
      _serverHost.Open();
      InitailChainOfCommand(out FirstCommand);
    }

    private ChainOfServerCommand<IFromServerToClientMessage> FirstCommand = null;
    private void InitailChainOfCommand(out ChainOfServerCommand<IFromServerToClientMessage> cosc) {
      ChainOfServerCommand<IFromServerToClientMessage> scw = new ServerCommandWindow();
      ChainOfServerCommand<IFromServerToClientMessage> scfp = new ServerCommandFlowPre();
      ChainOfServerCommand<IFromServerToClientMessage> scfc = new ServerCommandFlowCondition();
      ChainOfServerCommand<IFromServerToClientMessage> scpd = new ServerCommandPinData();
      ChainOfServerCommand<IFromServerToClientMessage> scpg = new ServerCommandPinGroup();
      ChainOfServerCommand<IFromServerToClientMessage> scur = new ServerCommandUserRelay();
      ChainOfServerCommand<IFromServerToClientMessage> scurg = new ServerCommandUserRelayGroup();
      ChainOfServerCommand<IFromServerToClientMessage> scdi = new ServerCommandDrivenInfo();
      ChainOfServerCommand<IFromServerToClientMessage> sctac = new ServerCommandTimingAC();
      ChainOfServerCommand<IFromServerToClientMessage> scdttpi = new ServerCommandDebugToolTestPgInfo();
      ChainOfServerCommand<IFromServerToClientMessage> scdtdpd = new ServerCommandDebugToolDumpPtnData();
      ChainOfServerCommand<IFromServerToClientMessage> scdtdtd = new ServerCommandDebugToolDumpTimData();
      ChainOfServerCommand<IFromServerToClientMessage> scdtdla = new ServerCommandDebugToolDumpLa();
      ChainOfServerCommand<IFromServerToClientMessage> scdtdcp = new ServerCommandDebugToolDumpCapture();
      ChainOfServerCommand<IFromServerToClientMessage> scdtdal = new ServerCommandDebugToolDumpAcLogData();
      ChainOfServerCommand<IFromServerToClientMessage> scsii = new ServerCommandShmooIniInfo();
      ChainOfServerCommand<IFromServerToClientMessage> scspi = new ServerCommandShmooPlanInfo();
      ChainOfServerCommand<IFromServerToClientMessage> scssi = new ServerCommandShmooSiteInfo();
      ChainOfServerCommand<IFromServerToClientMessage> scspgt = new ServerCommandShmooPinGroupTable();
      ChainOfServerCommand<IFromServerToClientMessage> scspfr = new ServerCommandShmooPFResult();  
      ChainOfServerCommand<IFromServerToClientMessage> scnm = new ServerCommandNormalMessage();
      scw.NextCommand = scfp;
      scfp.NextCommand = scfc;
      scfc.NextCommand = scpd;
      scpd.NextCommand = scpg;
      scpg.NextCommand = scur;
      scur.NextCommand = scurg;
      scurg.NextCommand = scdi;
      scdi.NextCommand = sctac;
      sctac.NextCommand = scdttpi;
      scdttpi.NextCommand = scdtdpd;
      scdtdpd.NextCommand = scdtdtd;
      scdtdtd.NextCommand = scdtdla;
      scdtdla.NextCommand = scdtdcp;
      scdtdcp.NextCommand = scdtdal;
      scdtdal.NextCommand = scsii;
      scsii.NextCommand = scspi;
      scspi.NextCommand = scssi;
      scssi.NextCommand = scspgt;
      scspgt.NextCommand = scspfr;
      scspfr.NextCommand = scnm;
      cosc = scw;
    }

    public void HostOff() {
      if (_serverHost != null)
        if (_serverHost.State != CommunicationState.Closed)
        {
          foreach (var reg in _registeredClients)
          {
            SendMessageToClient(reg, "ShutDown", null);
          }
          _serverHost.Close();
        }
       
    }
    public static Server GetInstance {
      get {
        if (instance == null)
          instance = new Server();
        return instance;
      }
    }

    public void SendMessageToClient(string clientName, string msgID, Object data) {
      if (_registeredClients.Contains(clientName)) {
        using (ChannelFactory<IFromServerToClientMessage> factory = new ChannelFactory<IFromServerToClientMessage>(new NetNamedPipeBinding(), new EndpointAddress($"net.pipe://localhost/YTEC_{clientName}"))) {
          IFromServerToClientMessage serverToClientChannel = factory.CreateChannel();
          try {
            FirstCommand.Execute(serverToClientChannel, msgID, data);

          }
          catch (CommunicationException ex) {
            //Trace.WriteLine(string.Format("SendMessageToClient: {0}", ex.ToString()));
            throw ex;
          }
          finally {
            CloseChannel((ICommunicationObject)serverToClientChannel);
          }
        }
      }
    }

    private void CloseChannel(ICommunicationObject channel) {
      try {
        channel.Close();
      }
      catch (CommunicationException ex) {
        throw ex;
      }
      finally {
        channel.Abort();
      }
    }

    public void Register(string clientID) {
      if (!_registeredClients.Contains(clientID))
        _registeredClients.Add(clientID);
    }

    public void SendMessage(string clientID, string msgID, object msg) {
      DataReady?.Invoke(clientID, msgID, msg);
    }

    public void Dispose() {
      this.HostOff();
    }

    public void UnRegister(string clientID) {
      if (_registeredClients.Contains(clientID))
        _registeredClients.Remove(clientID);
    }
    public void SendFlowPreMessage(string clientID, string msgID, FlowPreMessageArgs data) {
      DataReady?.Invoke(clientID, msgID, data);
    }
    public void SendFlowConditionMessage(string clientID, string msgID, FlowConditionMessageArgs data) {
      DataReady?.Invoke(clientID, msgID, data);
    }

    public void SendKenralUpdateValMessage(string clientID, string msgID, KernalUpdateValMessageArgs data) {
      DataReady?.Invoke(clientID, msgID, data);
    }

    public void SendDrivenInfoMessage(string clientID, string msgID, DriverInfoMessageArgs data) {
      DataReady?.Invoke(clientID, msgID, data);
    }

    public void SendDebugToolDumpPatternMessage(string clientID, string msgID, DebugToolDumpPatternMessageArgs data) {
      DataReady?.Invoke(clientID, msgID, data);
    }

    public void SendDebugToolDumpTimingMessage(string clientID, string msgID, DebugToolDumpTimingMessageArgs data) {
      DataReady?.Invoke(clientID, msgID, data);
    }

    public void SendDebugToolDumpAcLogMessage(string clientID, string msgID, DebugToolDumpAcLogMessageArgs data) {
      DataReady?.Invoke(clientID, msgID, data);
    }

    public void SendDebugToolDumpLaMessage(string clientID, string msgID, DebugToolDumpLaMessageArgs data) {
      DataReady?.Invoke(clientID, msgID, data);
    }

    public void SendDebugToolDumpCaptureMessage(string clientID, string msgID, DebugToolDumpCaptureMessageArgs data) {
      DataReady?.Invoke(clientID, msgID, data);
    }
  }
}
