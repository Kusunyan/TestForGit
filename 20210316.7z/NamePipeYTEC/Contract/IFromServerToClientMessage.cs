﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
  [ServiceContract]
  interface IFromServerToClientMessage
  {
    [OperationContract]
    void SendMessage(string msg, object data);

    [OperationContract]
    void SendWindowMessage(string msg, WindowMessageArgs data);
    [OperationContract]
    void SendFlowPreMessage(string msg, FlowPreMessageArgs data);
    [OperationContract]
    void SendFlowConditionMessage(string msg, FlowConditionMessageArgs data);
    [OperationContract]
    void SendTimingMessage(string msg, TimingMessageArgs data);
    [OperationContract]
    void SendPinGroupMessage(string msg, IOPinGroupMessageArgs data);
    [OperationContract]
    void SendPinMessage(string msg, IOPinMessageArgs data);
    [OperationContract]
    void SendUserRelayGroupMessage(string msg, UserRelayGroupMessageArgs data);
    [OperationContract]
    void SendUserRelayMessage(string msg, UserRelayMessageArgs data);
    [OperationContract]
    void SendDrivenInfoMessage(string msg, DriverInfoMessageArgs data);
    [OperationContract]
    void SendPatternLabelListMessage(string msg, DebugToolTestPgInfofoMessageArgs data);
    [OperationContract]
    void SendDebugToolDumpPatternMessage(string msg, DebugToolDumpPatternMessageArgs data);
    [OperationContract]
    void SendDebugToolDumpTimingMessage(string msg, DebugToolDumpTimingMessageArgs data);
    [OperationContract]
    void SendDebugToolDumpAcLogMessage(string msg, DebugToolDumpAcLogMessageArgs data);
    [OperationContract]
    void SendDebugToolDumpLaMessage(string msg, DebugToolDumpLaMessageArgs data);
    [OperationContract]
    void SendDebugToolDumpCaptureMessage(string msg, DebugToolDumpCaptureMessageArgs data);

    [OperationContract]
    void SendShmooIniInfoMessage(string msg, ShmooIniInfoMessageArgs data);
    [OperationContract]
    void SendShmooPlanInfoMessage(string msg, ShmooPlanInfoMessageArgs data);
    [OperationContract]
    void SendShmooSiteInfoMessage(string msg, ShmooSiteInfoMessageArgs data);
    [OperationContract]
    void SendShmooPinGroupTableMessage(string msg, ShmooPinGroupTableMessageArgs data);

    [OperationContract]
    void SendShmooPFResultMessage(string msg, ShmooPFResultMessageArgs data);

    event Action<string, object> ServerDataIsReady;
  }
}
