﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
    [ServiceContract]
    public interface IDuplexCallbackMessage
    {
        [OperationContract(IsOneWay = true)]
        void PostMessage(string msg, object data);

        [OperationContract(IsOneWay = true)]
        void PostWindowMessage(string msg, WindowMessageArgs data);
        [OperationContract(IsOneWay = true)]
        void PostFlowPreMessage(string msg, FlowPreMessageArgs data);
        [OperationContract(IsOneWay = true)]
        void PostFlowConditionMessage(string msg, FlowConditionMessageArgs data);
        [OperationContract(IsOneWay = true)]
        void PostTimingMessage(string msg, TimingMessageArgs data);
        [OperationContract(IsOneWay = true)]
        void PostPinGroupMessage(string msg, IOPinGroupMessageArgs data);
        [OperationContract(IsOneWay = true)]
        void PostPinMessage(string msg, IOPinMessageArgs data);
        [OperationContract(IsOneWay = true)]
        void PostUserRelayGroupMessage(string msg, UserRelayGroupMessageArgs data);
        [OperationContract(IsOneWay = true)]
        void PostUserRelayMessage(string msg, UserRelayMessageArgs data);
        [OperationContract(IsOneWay = true)]
        void PostDrivenInfoMessage(string msg, DriverInfoMessageArgs data);
        [OperationContract(IsOneWay = true)]
        void PostPatternLabelListMessage(string msg, DebugToolTestPgInfofoMessageArgs data);
        [OperationContract(IsOneWay = true)]
        void PostDebugToolDumpPatternMessage(string msg, DebugToolDumpPatternMessageArgs data);

        [OperationContract(IsOneWay = true)]
        void PostShmooIniInfoMessage(string msg, ShmooIniInfoMessageArgs data);
        [OperationContract(IsOneWay = true)]
        void PostShmooPlanInfoMessage(string msg, ShmooPlanInfoMessageArgs data);
        [OperationContract(IsOneWay = true)]
        void PostShmooSiteInfoMessage(string msg, ShmooSiteInfoMessageArgs data);
        [OperationContract(IsOneWay = true)]
        void PostShmooPinGroupTableMessage(string msg, ShmooPinGroupTableMessageArgs data);

        [OperationContract(IsOneWay = true)]
        void PostShmooPFResultMessage(string msg, ShmooPFResultMessageArgs data);
    [OperationContract(IsOneWay = true)]
    void PostLADataMessage(string msg, LADataMessageArgs data);
    [OperationContract(IsOneWay = true)]
    void PostLATimingMessage(string msg, LATimingMessageArgs data);
    [OperationContract(IsOneWay = true)]
    void PostCollectionMessage(string msg, List<object> data);

    event Action<string, object> ServerDataIsReady;
    }
}
