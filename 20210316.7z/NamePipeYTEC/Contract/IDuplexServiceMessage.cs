﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
  [ServiceContract(CallbackContract = typeof(IDuplexCallbackMessage), SessionMode = SessionMode.Required)]
  public interface IDuplexServiceMessage
  {

    [OperationContract(IsOneWay = true)]
    void SubScribe(string clientID);

    [OperationContract(IsOneWay = true)]
    void UnSubScribe(string clientID);

    [OperationContract(IsOneWay = true)]
    void PostMessage(string clientID, string msgID, object msg);
    [OperationContract(IsOneWay = true)]
    void PostCollectionMessage(string clientID, string msgID, List<object> msg);

    [OperationContract(IsOneWay = true)]
    void PostFlowPreMessage(string clientID, string msg, FlowPreMessageArgs data);
    [OperationContract(IsOneWay = true)]
    void PostFlowConditionMessage(string clientID, string msg, FlowConditionMessageArgs data);
    [OperationContract(IsOneWay = true)]
    void PostKenralUpdateValMessage(string clientID, string msg, KernalUpdateValMessageArgs data);
    [OperationContract(IsOneWay = true)]
    void PostDrivenInfoMessage(string clientID, string msg, DriverInfoMessageArgs data);
    [OperationContract(IsOneWay = true)]
    void PostDebugToolDumpPatternMessage(string clientID, string msg, DebugToolDumpPatternMessageArgs data);



    event Action<string, string, object> ClientDataIsReady;
  }
}
