﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
  [ServiceContract]
  internal interface IFromClientToServerMessage
  {
    [OperationContract]
    void Register(string clientID);

    [OperationContract]
    void UnRegister(string clientID);

    [OperationContract]
    void SendMessage(string clientID, string msgID, object msg);

    [OperationContract]
    void SendFlowPreMessage(string clientID, string msg, FlowPreMessageArgs data);
    [OperationContract]
    void SendFlowConditionMessage(string clientID, string msg, FlowConditionMessageArgs data);
    [OperationContract]
    void SendKenralUpdateValMessage(string clientID, string msg, KernalUpdateValMessageArgs data);
    [OperationContract]
    void SendDrivenInfoMessage(string clientID, string msg, DriverInfoMessageArgs data);
    [OperationContract]
    void SendDebugToolDumpPatternMessage(string clientID, string msg, DebugToolDumpPatternMessageArgs data);
    [OperationContract]
    void SendDebugToolDumpTimingMessage(string clientID, string msg, DebugToolDumpTimingMessageArgs data);
    [OperationContract]
    void SendDebugToolDumpAcLogMessage(string clientID, string msg, DebugToolDumpAcLogMessageArgs data);
    [OperationContract]
    void SendDebugToolDumpLaMessage(string clientID, string msg, DebugToolDumpLaMessageArgs data);
    [OperationContract]
    void SendDebugToolDumpCaptureMessage(string clientID, string msg, DebugToolDumpCaptureMessageArgs data);

    event Action<string, string, object> ClientDataIsReady;
  }
}
