﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
  [DataContract]
  public class TimingMessageArgs
  {
    //List<ACSetMessageArgs> _ACSetList;
    //List<WaveTableMessageArgs> _WaveTableList;
    [DataMember]
    public List<ACSetMessageArgs> ACSetList = new List<ACSetMessageArgs>();

    [DataMember]
    public List<WaveTableMessageArgs> WaveTableList = new List<WaveTableMessageArgs>();

  }
  [DataContract]
  public class ACSetMessageArgs
  {
    [DataMember]
    public int ACSetNo { get; set; }
    [DataMember]
    public int GroupNo { get; set; }
  }
  [DataContract]
  public class WaveTableMessageArgs
  {
    [DataMember]
    public int WaveTableNo { get; set; }
    [DataMember]
    public string Name { get; set; }
  }
}
