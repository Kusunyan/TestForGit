﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
  [DataContract]
  public class UserRelayGroupMessageArgs
  {
    [DataMember]
    public string Name { get; set; }
    [DataMember]
    public List<UserRelayMessageArgs> UserRelayList = new List<UserRelayMessageArgs>();
  }
  [DataContract]
  public class UserRelayMessageArgs
  {
    [DataMember]
    public string Name { get; set; }
    [DataMember]
    public List<int> RelayNoList = new List<int>();
  }
}
