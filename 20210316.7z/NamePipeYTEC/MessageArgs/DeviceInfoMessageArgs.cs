﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
    [DataContract]
    public class DeviceMessageArgs
    {
        [DataMember]
        public List<IOPinMessageArgs> IoPinList = new List<IOPinMessageArgs>();
        [DataMember]
        public List<IOPinGroupMessageArgs> IoPinGroupList = new List<IOPinGroupMessageArgs>();
        [DataMember]
        public List<IOPinMessageArgs> PwrPinList = new List<IOPinMessageArgs>();
        [DataMember]
        public List<IOPinGroupMessageArgs> PwrPinGroupList = new List<IOPinGroupMessageArgs>();
        [DataMember]
        public List<UserRelayMessageArgs> UserRelayList = new List<UserRelayMessageArgs>();
        [DataMember]
        public List<UserRelayGroupMessageArgs> UserRelayGroupList = new List<UserRelayGroupMessageArgs>();
        [DataMember]
        public List<UserRelayMessageArgs> I2cBusList = new List<UserRelayMessageArgs>();
        [DataMember]
        public List<UserRelayGroupMessageArgs> I2cBusGroupList = new List<UserRelayGroupMessageArgs>();
    }
}
