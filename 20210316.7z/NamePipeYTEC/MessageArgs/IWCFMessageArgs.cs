﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
  public interface IWCFFlowPreArgs
  {
    string PlanName { get; set; }
    int PlanIndex { get; set; }
    string SiteSequence { get; set; }

    string GoThrough { get; set; }

    string DisableByMarkNo { get; set; }

    string EnableByMarkNo { get; set; }
    string Remark { get; set; }
    string PowerDownPlan { get; set; }
  }
  public interface IWCFFlowConditionArgs
  {
    string PlanName { get; set; }
    int PlanIndex { get; set; }
    List<String> planCollection { get; set; }

    string PassLoopCount { get; set; }
    string PassRejectBin { get; set; }
    string PassSortTable { get; set; }
    string PassMarkNo { get; set; }
    string PassBranch { get; set; }


    string FailLoopCount { get; set; }
    string FailRejectBin { get; set; }
    string FailSortTable { get; set; }
    string FailMarkNo { get; set; }
    string FailBranch { get; set; }


    string UnconLoopCount { get; set; }
    string UnconRejectBin { get; set; }
    string UnconSortTable { get; set; }
    string UnconMarkNo { get; set; }
    string UnconBranch { get; set; }
  }

  public interface IWCFWindowArgs
  {
    string MessageType { get; set; }
    int PageIndex { get; set; }
    int LocationX { get; set; }
    int LocationY { get; set; }
    int Width { get; set; }
    int Height { get; set; }
  }

  public interface IWCFDriverInfoArgs
  {
    string m_szPlanName { get; set; }

    int m_iPgmTreePlanIdx { get; set; }

    int m_iDriverIdx { get; set; }

    uint m_uiTestSite { get; set; }

    string m_szLastModificationStatus { get; set; }

    int m_iDrvSN { get; set; }

    int m_iLineNo { get; set; }

    uint m_uiDrvID { get; set; }

    uint m_uiDrvParamCnt { get; set; }

    List<int> m_AiUnOrderedParamSeq { get; set; }

    string m_szSource { get; set; }

    string m_szRemark { get; set; }

    string m_szDrvName { get; set; }


    int m_iName { get; set; }

    int m_iKeepState { get; set; }

    int m_iForceReadMode { get; set; }

    int m_iERange { get; set; }

    int m_iIRange { get; set; }

    int m_iWait1No { get; set; }

    int m_iWait2No { get; set; }

    int m_iWait1Kind { get; set; }

    int m_iWait2Kind { get; set; }

    int m_iLogName { get; set; }

    int m_iLogUnit { get; set; }

    int m_iMeasLoop { get; set; }

    int m_iUserMonitor { get; set; }

    int m_iBinNo { get; set; }

    int m_iIgnoreFail { get; set; }

    int m_iTestNumber { get; set; }

    int m_iSpecAlias { get; set; }

    int m_iBeyond { get; set; }

    int m_iSiteSelect { get; set; }

    int m_iSlewRate { get; set; }

    int m_iForceMode { get; set; }

    int m_iAdcGoNoGo { get; set; }

    List<int> m_iReserve { get; set; }

    double m_dFValue { get; set; }

    double m_dFIValue { get; set; }

    double m_dFNIValue { get; set; }

    double m_dClamp { get; set; }

    double m_dUpLimit { get; set; }

    double m_dDownLimit { get; set; }

    double m_dFVOffset { get; set; }

    double m_dFIOffset { get; set; }

    double m_dFNIOffset { get; set; }

    double m_dCVOffset { get; set; }

    double m_dUpLimitOffset { get; set; }

    double m_dDownLimitOffset { get; set; }

    double m_dWait1 { get; set; }

    double m_dWait2 { get; set; }

    List<double> m_dReserve { get; set; }

    string m_szName { get; set; }

    string m_szPtnStartLabel { get; set; }

    string m_szPtnEndLabel { get; set; }

    string m_szResource { get; set; }

    string m_szFValue { get; set; }

    string m_szFIValue { get; set; }

    string m_szFNIValue { get; set; }

    string m_szClamp { get; set; }

    string m_szUpLimit { get; set; }

    string m_szDownLimit { get; set; }

    string m_szFVOffset { get; set; }

    string m_szFIOffset { get; set; }

    string m_szFNIOffset { get; set; }

    string m_szCVOffset { get; set; }

    string m_szUpLimitOffset { get; set; }

    string m_szDownLimitOffset { get; set; }

    string m_szERange { get; set; }

    string m_szIRange { get; set; }

    string m_szWait1 { get; set; }

    string m_szWait2 { get; set; }

    string m_szWait1No { get; set; }

    string m_szWait2No { get; set; }

    string m_szWait1Kind { get; set; }

    string m_szWait2Kind { get; set; }

    string m_szLogName { get; set; }

    string m_szLogUnit { get; set; }

    string m_szLogPin { get; set; }

    string m_szMeasLoop { get; set; }

    string m_szUserMonitor { get; set; }

    string m_szBinNo { get; set; }

    string m_szIgnoreFail { get; set; }

    string m_szTestNumber { get; set; }

    string m_szSpecAlias { get; set; }

    string m_szBeyond { get; set; }

    string m_szSiteSelect { get; set; }

    string m_szSlewRate { get; set; }

    string m_szForceMode { get; set; }

    string m_szAdcGoNoGo { get; set; }

    List<string> m_szReserve { get; set; }
  }

}
