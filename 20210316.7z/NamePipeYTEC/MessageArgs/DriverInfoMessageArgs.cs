﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
    [DataContract]
    public class DriverInfoMessageArgs: IWCFDriverInfoArgs
    {
        [DataMember]
        public string m_szPlanName { get; set; }
        [DataMember]
        public int m_iPgmTreePlanIdx { get; set; }
        [DataMember]
        public int m_iDriverIdx { get; set; }
        [DataMember]
        public uint m_uiTestSite { get; set; }
        [DataMember]
        public string m_szLastModificationStatus { get; set; }
        [DataMember]
        public int m_iDrvSN { get; set; }
        [DataMember]
        public int m_iLineNo { get; set; }
        [DataMember]
        public uint m_uiDrvID { get; set; }
        [DataMember]
        public uint m_uiDrvParamCnt { get; set; }
        [DataMember]
        public List<int> m_AiUnOrderedParamSeq { get; set; }
        [DataMember]
        public string m_szSource { get; set; }
        [DataMember]
        public string m_szRemark { get; set; }
        [DataMember]
        public string m_szDrvName { get; set; }

        [DataMember]
        public int m_iName { get; set; }
        [DataMember]
        public int m_iKeepState { get; set; }
        [DataMember]
        public int m_iForceReadMode { get; set; }
        [DataMember]
        public int m_iERange { get; set; }
        [DataMember]
        public int m_iIRange { get; set; }
        [DataMember]
        public int m_iWait1No { get; set; }
        [DataMember]
        public int m_iWait2No { get; set; }
        [DataMember]
        public int m_iWait1Kind { get; set; }
        [DataMember]
        public int m_iWait2Kind { get; set; }
        [DataMember]
        public int m_iLogName { get; set; }
        [DataMember]
        public int m_iLogUnit { get; set; }
        [DataMember]
        public int m_iMeasLoop { get; set; }
        [DataMember]
        public int m_iUserMonitor { get; set; }
        [DataMember]
        public int m_iBinNo { get; set; }
        [DataMember]
        public int m_iIgnoreFail { get; set; }
        [DataMember]
        public int m_iTestNumber { get; set; }
        [DataMember]
        public int m_iSpecAlias { get; set; }
        [DataMember]
        public int m_iBeyond { get; set; }
        [DataMember]
        public int m_iSiteSelect { get; set; }
        [DataMember]
        public int m_iSlewRate { get; set; }
        [DataMember]
        public int m_iForceMode { get; set; }
        [DataMember]
        public int m_iAdcGoNoGo { get; set; }
        [DataMember]
        public List<int> m_iReserve { get; set; }
        [DataMember]
        public double m_dFValue { get; set; }
        [DataMember]
        public double m_dFIValue { get; set; }
        [DataMember]
        public double m_dFNIValue { get; set; }
        [DataMember]
        public double m_dClamp { get; set; }
        [DataMember]
        public double m_dUpLimit { get; set; }
        [DataMember]
        public double m_dDownLimit { get; set; }
        [DataMember]
        public double m_dFVOffset { get; set; }
        [DataMember]
        public double m_dFIOffset { get; set; }
        [DataMember]
        public double m_dFNIOffset { get; set; }
        [DataMember]
        public double m_dCVOffset { get; set; }
        [DataMember]
        public double m_dUpLimitOffset { get; set; }
        [DataMember]
        public double m_dDownLimitOffset { get; set; }
        [DataMember]
        public double m_dWait1 { get; set; }
        [DataMember]
        public double m_dWait2 { get; set; }
        [DataMember]
        public List<double> m_dReserve { get; set; }
        [DataMember]
        public string m_szName { get; set; }
        [DataMember]
        public string m_szPtnStartLabel { get; set; }
        [DataMember]
        public string m_szPtnEndLabel { get; set; }
        [DataMember]
        public string m_szResource { get; set; }
        [DataMember]
        public string m_szFValue { get; set; }
        [DataMember]
        public string m_szFIValue { get; set; }
        [DataMember]
        public string m_szFNIValue { get; set; }
        [DataMember]
        public string m_szClamp { get; set; }
        [DataMember]
        public string m_szUpLimit { get; set; }
        [DataMember]
        public string m_szDownLimit { get; set; }
        [DataMember]
        public string m_szFVOffset { get; set; }
        [DataMember]
        public string m_szFIOffset { get; set; }
        [DataMember]
        public string m_szFNIOffset { get; set; }
        [DataMember]
        public string m_szCVOffset { get; set; }
        [DataMember]
        public string m_szUpLimitOffset { get; set; }
        [DataMember]
        public string m_szDownLimitOffset { get; set; }
        [DataMember]
        public string m_szERange { get; set; }
        [DataMember]
        public string m_szIRange { get; set; }
        [DataMember]
        public string m_szWait1 { get; set; }
        [DataMember]
        public string m_szWait2 { get; set; }
        [DataMember]
        public string m_szWait1No { get; set; }
        [DataMember]
        public string m_szWait2No { get; set; }
        [DataMember]
        public string m_szWait1Kind { get; set; }
        [DataMember]
        public string m_szWait2Kind { get; set; }
        [DataMember]
        public string m_szLogName { get; set; }
        [DataMember]
        public string m_szLogUnit { get; set; }
        [DataMember]
        public string m_szLogPin { get; set; }
        [DataMember]
        public string m_szMeasLoop { get; set; }
        [DataMember]
        public string m_szUserMonitor { get; set; }
        [DataMember]
        public string m_szBinNo { get; set; }
        [DataMember]
        public string m_szIgnoreFail { get; set; }
        [DataMember]
        public string m_szTestNumber { get; set; }
        [DataMember]
        public string m_szSpecAlias { get; set; }
        [DataMember]
        public string m_szBeyond { get; set; }
    [DataMember]
        public string m_szSiteSelect { get; set; }
    [DataMember]
        public string m_szSlewRate { get; set; }
        [DataMember]
        public string m_szForceMode { get; set; }
        [DataMember]
        public string m_szAdcGoNoGo { get; set; }
        [DataMember]
        public List<string> m_szReserve { get; set; }
    }
  
    public class CChDataReceive
    {
        [DataMember]
        public int m_iBoardType { get; set; }
        [DataMember]
        public int m_iChNo { get; set; }
    }
  [DataContract]
    public class CPinDataReceive
    {
        [DataMember]
        public string m_szPinName { get; set; }
        [DataMember]
        public int m_iPinNo { get; set; }
        [DataMember]
        public int m_iPwrType { get; set; }
        [DataMember]
        public List<CChDataReceive> m_ChDataList = new List<CChDataReceive>();
    }
    [DataContract]
    public class CPinGroupReceive
    {
        [DataMember]
        public string m_szName { get; set; }
        [DataMember]
        public List<CPinDataReceive> m_PinDataList = new List<CPinDataReceive>();
    }
    [DataContract]
    public class CAcSetReceive
    {
        [DataMember]
        public int m_iGroup { get; set; }
        [DataMember]
        public int m_iAcSet { get; set; }
    }
    [DataContract]
    public class CWaveTableReceive
    {
        [DataMember]
        public int m_iWaveTableNo;
        [DataMember]
        public string m_szName;
    }


}
