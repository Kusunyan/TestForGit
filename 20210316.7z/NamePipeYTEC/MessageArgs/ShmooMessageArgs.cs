﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{

  [DataContract]
  public class ShmooIniInfoMessageArgs
  {
    [DataMember]
    public bool m_bHsPtn512T { get; set; }
    [DataMember]
    public string m_cDrvDefIni { get; set; }
    [DataMember]
    public string m_cParaDefIni { get; set; }
    [DataMember]
    public string m_cSpecDefIni { get; set; }
    [DataMember]
    public string m_cShmooPath { get; set; }
    [DataMember]
    public string m_cSettingIni { get; set; }
    [DataMember]
    public string m_cHandshakingIni { get; set; }
  }
  [DataContract]
  public class ShmooPlanInfoMessageArgs
  {
    [DataMember]
    public string m_cPlanName { get; set; }
    [DataMember]
    public int m_iDrvCnt { get; set; }
    [DataMember]
    public int m_iMacroCnt { get; set; }
  }
  [DataContract]
  public class ShmooSiteInfoMessageArgs
  {
    [DataMember]
    public int m_iSiteCount;
    [DataMember]
    public List<int> m_iSiteNo = new List<int>();
  }
  [DataContract]
  public class ShmooPinGroupTableMessageArgs
  {
    [DataMember]
    public List<string> m_szGroupName = new List<string>();
    [DataMember]
    public List<int> m_iPinCnt = new List<int>();
    [DataMember]
    public List<bool> m_bLcdGrp = new List<bool>();
    [DataMember]
    public List<int> m_iGroupIdx = new List<int>();
  }

  [DataContract]
  public class ShmooPFResultMessageArgs
  {
    [DataMember]
    public int m_uiRunMode;
    [DataMember]
    public int m_iX;
    [DataMember]
    public int m_iY;
    [DataMember]
    public List<SitePFResult> m_iSite = new List<SitePFResult>();
  }
  [DataContract]
  public class SitePFResult
  {
    [DataMember]
    public List<string> m_cPfResult = new List<string>();
    [DataMember]
    public List<int> m_iFailCount = new List<int>();
  }
}
