﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
  #region TestPgInfo
  [DataContract]
  public class DebugToolTestPgInfofoMessageArgs
  {
    //public DebugToolTestPgInfofoMessageArgs ShallowCopy() {
    //  return (DebugToolTestPgInfofoMessageArgs)this.MemberwiseClone();
    //}
    [DataMember]
    public string PjFullPath { get; set; }
    [DataMember]
    public List<uint> SlotKindList = new List<uint>();
    [DataMember]
    public List<DebugToolPtnLabelMessageArgs> PtnLabelList = new List<DebugToolPtnLabelMessageArgs>();
    [DataMember]
    public List<DebugToolTimingGroupMessageArgs> TimGroupList = new List<DebugToolTimingGroupMessageArgs>();
  }
  [DataContract]
  public class DebugToolPtnLabelMessageArgs
  {
    [DataMember]
    public string PtnName { get; set; }
    [DataMember]
    public List<DebugToolLabelAddrMessageArgs> LabelList = new List<DebugToolLabelAddrMessageArgs>();
  }
  [DataContract]
  public class DebugToolLabelAddrMessageArgs
  {
    [DataMember]
    public string LabelName;
    [DataMember]
    public uint PtnAddr;
  }
  [DataContract]
  public class DebugToolTimingGroupMessageArgs
  {
    [DataMember]
    public uint GroupNo { get; set; }
    [DataMember]
    public List<DebugToolAcSetMessageArgs> AcSetList = new List<DebugToolAcSetMessageArgs>();
  }
  [DataContract]
  public class DebugToolAcSetMessageArgs
  {
    [DataMember]
    public uint AcSetIdx;
    [DataMember]
    public uint AcSetNo;
    [DataMember]
    public uint EdgeStartAddr;
    [DataMember]
    public int ReserveEdges;
    [DataMember]
    public string AcSetName;
    [DataMember]
    public double TimRes;
  }
  #endregion

  #region DumpPattern
  [DataContract]
  public class DebugToolDumpPatternMessageArgs
  {
    //public DebugToolDumpPatternMessageArgs ShallowCopy() {
    //  return (DebugToolDumpPatternMessageArgs)this.MemberwiseClone();
    //}
    [DataMember]
    public uint SpmIdx;
    [DataMember]
    public uint PtnStartAddr;
    [DataMember]
    public uint PtnCount;
    [DataMember]
    public List<DebugToolPtnDataMessageArgs> PtnVectorList = new List<DebugToolPtnDataMessageArgs>();
  }
  [DataContract]
  public class DebugToolPtnDataMessageArgs
  {
    [DataMember]
    public uint MI;
    [DataMember]
    public uint F_;
    [DataMember]
    public uint DA;
    [DataMember]
    public uint MA;
    [DataMember]
    public uint CT;
    [DataMember]
    public string PtnLabel;
    [DataMember]
    public string PtnData;
    [DataMember]
    public string PtnMi;
  }
  #endregion

  #region DumpTiming
  [DataContract]
  public class DebugToolDumpTimingMessageArgs
  {
    [DataMember]
    public uint SpmIdx;
    [DataMember]
    public uint AcSetIdx;
    [DataMember]
    public uint GroupNo;
    [DataMember]
    public uint ACSetNo;
    [DataMember]
    public uint PeriodT;
    [DataMember]
    public List<uint> EdgeRAMList = new List<uint>();
    [DataMember]
    public List<uint> ChTsRAMList = new List<uint>();
    [DataMember]
    public List<List<uint>> ChEdgeSelectRAMList = new List<List<uint>>();
  }
  #endregion

  #region DumpAcLog
  [DataContract]
  public class DebugToolDumpAcLogMessageArgs
  {
    [DataMember]
    public uint SpmIdx;
    [DataMember]
    public uint LogCount;
    [DataMember]
    public List<DebugToolAcLogDataMessageArgs> AcLogList = new List<DebugToolAcLogDataMessageArgs>();
  }

  [DataContract]
  public class DebugToolAcLogDataMessageArgs
  {
    [DataMember]
    public uint PtnAddr;
    [DataMember]
    public uint RepeatCount;
    [DataMember]
    public uint SubRepeatCount;
    [DataMember]
    public uint LM;
    [DataMember]
    public uint LzAddr;
    [DataMember]
    public uint CallSubAddr;
    [DataMember]
    public uint ChnPinPF;
  }
  #endregion

  #region DumpLA
  [DataContract]
  public class DebugToolDumpLaMessageArgs
  {
    [DataMember]
    public uint SpmIdx;
    [DataMember]
    public List<DebugToolLzRamDataMessageArgs> LzRamList = new List<DebugToolLzRamDataMessageArgs>();
  }

  [DataContract]
  public class DebugToolLzRamDataMessageArgs
  {
    [DataMember]
    public uint Block1;
    [DataMember]
    public uint Block0;
    [DataMember]
    public uint T0LogAddr;
  }
  #endregion

  #region DumpCapture
  [DataContract]
  public class DebugToolDumpCaptureMessageArgs
  {
    [DataMember]
    public uint SpmIdx;
    [DataMember]
    public uint Offset;
    [DataMember]
    public uint Count;
    [DataMember]
    public bool GetAddr;
    [DataMember]
    public List<DebugToolCaptureRamMessageArgs> CaptureRamList = new List<DebugToolCaptureRamMessageArgs>();
  }

  [DataContract]
  public class DebugToolCaptureRamMessageArgs
  {
    [DataMember]
    public uint Addr;
    [DataMember]
    public uint Data;
  }
  #endregion
}

