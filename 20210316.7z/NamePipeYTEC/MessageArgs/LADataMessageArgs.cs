﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
  [DataContract]
  public class LADataMessageArgs
  {
    [DataMember]
    public string DriverName { get; set; }
    [DataMember]
    public int PatternGroupNo { get; set; }
    [DataMember]
    public int PatternACSetNo { get; set; }
    [DataMember]
    public int HsBitsPerLane { get; set; }
    [DataMember]
    public double MaxRbfOffset { get; set; }
    [DataMember]
    public int PinCnt { get; set; }
    [DataMember]
    public int PrgLine { get; set; }
    [DataMember]
    public int SamResIdx { get; set; }
    [DataMember]
    public double SystemClock { get; set; }
    [DataMember]
    public string PtnStartLabel { get; set;   }
    [DataMember]
    public int PtnStartAddress { get; set; }
    [DataMember]
    public string PatternLabel { get; set; }
    [DataMember]
    public List<List<int>> HsChDelayStepOfSlot = new List<List<int>>();
  
    [DataMember]
    public List<IOPinMessageArgs> PinInfos = new List<IOPinMessageArgs>();
    [DataMember]
    public List<SiteInfoMessageArgs> RunSiteInfo = new List<SiteInfoMessageArgs>();
    //[DataMember]
    //public List<PatternInfoMessageArgs> PatternInfos = new List<PatternInfoMessageArgs>();
    //[DataMember]
    //public List<LzRamBitDataMessageArgs> LzRamBitDatas = new List<LzRamBitDataMessageArgs>();   
    //[DataMember]
    //public List<LzRamAddrInfoMessageArgs> LzRamAddrInfos = new List<LzRamAddrInfoMessageArgs>();
    //[DataMember]
    //public List<LzRamBoardMessageArgs> LzRamBoardInfos = new List<LzRamBoardMessageArgs>();
    [DataMember]
    public List<DebugToolDumpAcLogMessageArgs> ACLogRamInfos = new List<DebugToolDumpAcLogMessageArgs>(); 
    [DataMember]
    public List<DebugToolDumpPatternMessageArgs> PatternDatas = new List<DebugToolDumpPatternMessageArgs>();
    [DataMember]
    public List<DebugToolDumpLaMessageArgs> LzRamAddressInfos = new List<DebugToolDumpLaMessageArgs>();
    //public List<DebugToolLzRamDataMessageArgs> LzRamInfos = new List<DebugToolLzRamDataMessageArgs>();
    [DataMember]
    public List<uint> SlotKindList = new List<uint>();
    [DataMember]
    public List<DebugToolPtnLabelMessageArgs> PtnLabelList = new List<DebugToolPtnLabelMessageArgs>();
    [DataMember]
    public List<DebugToolTimingGroupMessageArgs> TimGroupList = new List<DebugToolTimingGroupMessageArgs>();
    [DataMember]
    public List<DebugToolDumpTimingMessageArgs> TimingRAMS = new List<DebugToolDumpTimingMessageArgs>();
  }
  [DataContract]
  public class LATimingMessageArgs
  {
    [DataMember]
    public List<DebugToolDumpLaMessageArgs> LzRamAddressInfos = new List<DebugToolDumpLaMessageArgs>();
    [DataMember]
    public double MaxRbfOffset { get; set; }
    [DataMember]
    public List<DebugToolDumpAcLogMessageArgs> ACLogRamInfos = new List<DebugToolDumpAcLogMessageArgs>();
    [DataMember]
    public List<DebugToolDumpPatternMessageArgs> PatternDatas = new List<DebugToolDumpPatternMessageArgs>();
    [DataMember]
    public List<DebugToolDumpTimingMessageArgs> TimingRAMS = new List<DebugToolDumpTimingMessageArgs>();
    //[DataMember]
    //public List<MultiEdgeMessageArgs<int, EdgeDataMessageArgs<int>>> DriverRs = new List<MultiEdgeMessageArgs<int, EdgeDataMessageArgs<int>>>();
    //[DataMember]
    //public List<MultiEdgeMessageArgs<int, EdgeDataMessageArgs<int>>> DriverFl = new List<MultiEdgeMessageArgs<int, EdgeDataMessageArgs<int>>>();
    //[DataMember]
    //public List<EdgeDataMessageArgs<Double>> StrobeRs = new List<EdgeDataMessageArgs<double>>();
    //[DataMember]
    //public List<EdgeDataMessageArgs<Double>> StrobeFl = new List<EdgeDataMessageArgs<double>>();
    //[DataMember]
    //public List<EdgeDataMessageArgs<Double>> DelayDrvFly = new List<EdgeDataMessageArgs<double>>();
    //[DataMember]
    //public List<EdgeDataMessageArgs<int>> DrvFormat = new List<EdgeDataMessageArgs<int>>();
  }
  //[DataContract]
  //public class EdgeDataMessageArgs<T>
  //{

  //  public List<T> _edgesValue = new List<T>();
  //  public T this[int index]
  //  {
  //    get
  //    {
  //      return _edgesValue[index];
  //    }
  //  }
  //  [DataMember]
  //  public List<T> EdgesValue
  //  {
  //    get
  //    {
  //      return _edgesValue;
  //    }
  //    set
  //    {
  //      _edgesValue = value;
  //    }
  //  }
  //}
  //[DataContract]
  //public class MultiEdgeMessageArgs<T, S> where S : EdgeDataMessageArgs<T>
  //{
  //   List<S> _multiEdgesValue = new List<S>();

  //  public S this[int index]
  //  {
  //    get
  //    {
  //      return _multiEdgesValue[index];
  //    }
  //  }
  //  [DataMember]
  //  public List<S> MultiEdgesValue
  //  {
  //    get
  //    {
  //      return _multiEdgesValue;
  //    }
  //    set
  //    {
  //      _multiEdgesValue = value;
  //    }
  //  }
  //}

  public class SiteInfoMessageArgs
  {
    [DataMember]
    public bool IsActive { get; set; }
    [DataMember]
    public int SiteNo { get; set; }
    [DataMember]
    public List<int> ChNos = new List<int>();
    [DataMember]
    public List<int> HdigChNos = new List<int>();
  }
  [DataContract]
  public class LzRamAddrInfoMessageArgs
  {
    [DataMember]
    public int LogAddrT0 { get; set; }
    [DataMember]
    public List<LzRamBoardMessageArgs> BoardInfos = new List<LzRamBoardMessageArgs>();
  }
  [DataContract]
  public class LzRamBoardMessageArgs
  {
    [DataMember]
    public List<LzRamSPMMessageArgs> SPMInfos = new List<LzRamSPMMessageArgs>();
  }
  [DataContract]
  public class LzRamSPMMessageArgs
  {
    [DataMember]
    public int LzRamCnt { get; set; }
    [DataMember]
    public List<byte> ChStatus = new List<byte>();
    [DataMember]
    public List<UInt64> LogRam = new List<UInt64>();
  }
  [DataContract]
  public class LzRamBitDataMessageArgs
  {
    [DataMember]
    public List<uint> DA = new List<uint>();
    [DataMember]
    public List<uint> MA = new List<uint>();
    [DataMember]
    public List<uint> CT0 = new List<uint>();
    [DataMember]
    public List<uint> CT1 = new List<uint>();
    [DataMember]
    public List<uint> F = new List<uint>();
  }
}
