﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
    [DataContract]
    public class IOPinGroupMessageArgs
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public List<IOPinMessageArgs> PinDataList = new List<IOPinMessageArgs>();
            
    }

    [DataContract]
    public class IOPinMessageArgs
    {
        [DataMember]
        public int PinType { get; set; }
        [DataMember]
        public int PinNo { get; set; }
        [DataMember]
        public int PwrType { get; set; }
        [DataMember]
        public string PinName { get; set; }
        [DataMember]
        public List<CHDataMessageArgs> CHDataList = new List<CHDataMessageArgs>();
       
    }
    [DataContract]
    public class CHDataMessageArgs
    {
        [DataMember]
        public int BoardType { get; set; }
        [DataMember]
        public int ChNo { get; set; }
    }
}
