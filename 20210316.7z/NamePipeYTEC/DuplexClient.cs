﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace NamePipeYTEC
{
  //[ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Reentrant, InstanceContextMode = InstanceContextMode.Single)]
  public class DuplexClient : IDuplexCallbackMessage
  {
    //private static System.Diagnostics.TraceSource _myTraceSource =
    //      new System.Diagnostics.TraceSource("System.ServiceModel");
    IDuplexServiceMessage _proxy;
    private System.Timers.Timer  _timer;
    object _lockObject;
    protected Action<string, object> DataReady;
    public event Action<string, object> ServerDataIsReady
    {
      add
      {
        DataReady += value;
      }
      remove
      {
        DataReady -= value;
      }
    }

    private string _clientID = "";
    public DuplexClient(string clientName)
    {
      _clientID = clientName;
      _lockObject = new object();
      InitailChainOfClienCommand(out FirstCommand);
      OpenDuplexChannel();
      InitialTimer();
    }

   

    private void InitialTimer()
    {
      _timer = new System.Timers.Timer(5000);
      this._timer.Elapsed += new System.Timers.ElapsedEventHandler((s,e)=> 
      {
        TimerTick(s);
      } );
      _timer.Start();     
    }
    private void OpenDuplexChannel()
    {
      //Task.Factory.StartNew(() =>
      //{
      //var binding =new NetNamedPipeBinding();
      //binding.ReceiveTimeout = new TimeSpan(0,0,60);
      //Stack Overflow
      //My experience is that, when using NetNamedPipes, the "ReceiveTimout" on the binding functions like an "Inactivity Timeout" rather than a receive timout.Note that this different than how a NetTCPBinding works.
      var binding = new NetNamedPipeBinding();
      binding.ReceiveTimeout =TimeSpan.MaxValue;
      binding.MaxBufferSize = 64 * 1024 *64*64;
      binding.MaxReceivedMessageSize = 64 * 1024 *64*64;
      binding.MaxBufferPoolSize = 512 * 1024 * 4;
      //binding.SendTimeout = new TimeSpan(0,0,60);
      DuplexChannelFactory<IDuplexServiceMessage> pipeFactory =
          new DuplexChannelFactory<IDuplexServiceMessage>(
              new InstanceContext(this),
             binding,
              new EndpointAddress("net.pipe://localhost/YTECDuplexServer"));   
        _proxy = pipeFactory.CreateChannel();   
        ((IClientChannel)_proxy).Faulted += new EventHandler(Speaker_Faulted);
        ((IClientChannel)_proxy).Opened += new EventHandler(Speaker_Opened);
        ((IClientChannel)_proxy).Open();
      //}
      //);  
    }

    private void Speaker_Opened(object sender, EventArgs e)
    {
      _proxy.SubScribe(this._clientID);
    }

    private void Speaker_Faulted(object sender, EventArgs e)
    {
      //這邊不確定機制為何?只要server發生 RecieveTimeout的話，基本上都連不回去了
      lock (_lockObject)
      {
        _timer.Stop();
        IClientChannel channel = sender as IClientChannel;
        if (channel != null)
        {
          channel.Abort();
          channel.Close();
        }
        AbortProxy();
        _timer.Start();
      }

      ////Enable the try again timer and attempt to reconnect
      //_timer=new Timer(TimerTick, null, 0, 5000);

    }
    private void AbortProxy()
    {
      if (_proxy != null)
      {
        ((IClientChannel)_proxy).Faulted -= new EventHandler(Speaker_Faulted);
        ((IClientChannel)_proxy).Opened -= new EventHandler(Speaker_Opened);
        ((IClientChannel)_proxy).Abort();
        ((IClientChannel)_proxy).Close();
        _proxy = null;
      }
    }

    void TimerTick(Object stateInfo)
    {
      lock (_lockObject)
      {
        ReConnect();
      }  
    }
    private void ReConnect()
    {
      if (_proxy != null && (((IClientChannel)_proxy).State == CommunicationState.Opened ||
          ((IClientChannel)_proxy).State == CommunicationState.Opening))
      {
        //PostMessage("Null", ""); //測試會不會掛掉
        return;
      }
      else
      {
        //目前會有問題
        AbortProxy();
        OpenDuplexChannel();
      }  
    }

    protected virtual void InitailChainOfClienCommand(out ChainOfClientCommand<IDuplexServiceMessage> firstCommand)
    {
      ChainOfClientCommand<IDuplexServiceMessage> ccdcm = new ClientCommandDuplexCollectionMessage();
      ChainOfClientCommand<IDuplexServiceMessage> ccdnm = new ClientCommandDuplexNormalMessage();

      ccdcm.NextCommand = ccdnm;
      firstCommand = ccdcm;
    
    }

    private ChainOfClientCommand<IDuplexServiceMessage> FirstCommand = null;

    private void HostOff()
    {
      //if (_clientHost != null)
      //    if (_clientHost.State != CommunicationState.Closed)
      //        _clientHost.Close();
    }
    private void DisConnect()
    {
      try
      {
        _timer.Stop();
        if (_proxy != null && (((IClientChannel)_proxy).State == CommunicationState.Opened ||
          ((IClientChannel)_proxy).State == CommunicationState.Opening))
        {
          _proxy.UnSubScribe(this._clientID);      
        }
        AbortProxy();
        //((IClientChannel)_proxy).Close(new TimeSpan(0, 0, 1));
      }
      catch (Exception ex)
      {
        string msg = ex.Message;
        throw;
      }
   
    }


    public void SendMessageToServer(string msgID, object data)
    {
      if (_proxy != null && (((IClientChannel)_proxy).State == CommunicationState.Opened ||
          ((IClientChannel)_proxy).State == CommunicationState.Opening))
      {
        FirstCommand.Execute(_proxy, _clientID, msgID, data);
      }     
    }
    public virtual void PostMessage(string msgID, object data)
    {
      DataReady?.Invoke(msgID, data);
    }
    public void Dispose()
    {
      DisConnect();
    }

    public virtual void PostFlowPreMessage(string msgID, FlowPreMessageArgs data)
    {
      DataReady?.Invoke(msgID, data);
    }
    public virtual void PostFlowConditionMessage(string msgID, FlowConditionMessageArgs data)
    {
      DataReady?.Invoke(msgID, data);
    }

    public virtual void PostWindowMessage(string msgID, WindowMessageArgs data)
    {
      DataReady?.Invoke(msgID, data);
    }

    public virtual void PostTimingMessage(string msgID, TimingMessageArgs data)
    {
      DataReady?.Invoke(msgID, data);
    }
    public virtual void PostPinGroupMessage(string msgID, IOPinGroupMessageArgs data)
    {
      DataReady?.Invoke(msgID, data);
    }
    public virtual void PostPinMessage(string msgID, IOPinMessageArgs data)
    {
      DataReady?.Invoke(msgID, data);
    }
    public virtual void PostUserRelayGroupMessage(string msgID, UserRelayGroupMessageArgs data)
    {
      DataReady?.Invoke(msgID, data);
    }
    public virtual void PostUserRelayMessage(string msgID, UserRelayMessageArgs data)
    {
      DataReady?.Invoke(msgID, data);
    }
    public virtual void PostDrivenInfoMessage(string msgID, DriverInfoMessageArgs data)
    {
      DataReady?.Invoke(msgID, data);
    }
    public void PostPatternLabelListMessage(string msgID, DebugToolTestPgInfofoMessageArgs data)
    {
      DataReady?.Invoke(msgID, data);
    }
    public void PostDebugToolDumpPatternMessage(string msgID, DebugToolDumpPatternMessageArgs data)
    {
      DataReady?.Invoke(msgID, data);
    }

    public virtual void PostShmooIniInfoMessage(string msg, ShmooIniInfoMessageArgs data)
    {
      DataReady?.Invoke(msg, data);
    }

    public virtual void PostShmooPlanInfoMessage(string msg, ShmooPlanInfoMessageArgs data)
    {
      DataReady?.Invoke(msg, data);
    }

    public virtual void PostShmooSiteInfoMessage(string msg, ShmooSiteInfoMessageArgs data)
    {
      DataReady?.Invoke(msg, data);
    }

    public virtual void PostShmooPinGroupTableMessage(string msg, ShmooPinGroupTableMessageArgs data)
    {
      DataReady?.Invoke(msg, data);
    }

    public virtual void PostShmooPFResultMessage(string msg, ShmooPFResultMessageArgs data)
    {
      DataReady?.Invoke(msg, data);
    }

    public virtual void PostLADataMessage(string msg, LADataMessageArgs data)
    {
      DataReady?.Invoke(msg, data);
    }

    public virtual void PostLATimingMessage(string msg, LATimingMessageArgs data)
    {
      DataReady?.Invoke(msg, data);
    }

    public virtual void PostCollectionMessage(string msg, List<object> data)
    {
      DataReady?.Invoke(msg, data);
    }
  }
}
