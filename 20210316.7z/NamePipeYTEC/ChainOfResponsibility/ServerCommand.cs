﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
  class ServerCommandWindow : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendWindowMessage(msgID, data as WindowMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "Window") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandFlowPre : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendFlowPreMessage(msgID, data as FlowPreMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "FlowPre") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandFlowCondition : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendFlowConditionMessage(msgID, data as FlowConditionMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "FlowCondition") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandPinData : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendPinMessage(msgID, data as IOPinMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "AddIOPin" || msgID == "AddIOPwr") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandPinGroup : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendPinGroupMessage(msgID, data as IOPinGroupMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "AddIOPinGroup" || msgID == "AddIOPwrGroup" || msgID == "GroupPinList") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandUserRelay : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendUserRelayMessage(msgID, data as UserRelayMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "AddUserRelay" || msgID == "AddI2CBus") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandUserRelayGroup : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendUserRelayGroupMessage(msgID, data as UserRelayGroupMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "AddUserRelayGroup" || msgID == "AddI2CBusGroup") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandTimingAC : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendTimingMessage(msgID, data as TimingMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "AddTimingAC") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandDrivenInfo : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendDrivenInfoMessage(msgID, data as DriverInfoMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "SetDrivenInfo" || msgID == "DriverData") {
        return true;
      }
      else {
        return false;
      }
    }
  }

  #region DebugTool
  class ServerCommandDebugToolTestPgInfo : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendPatternLabelListMessage(msgID, data as DebugToolTestPgInfofoMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "TestPgInfo") {
        //Trace.WriteLine(string.Format("YtPrairieDbg: <wcf_server> IsMyResponsibility({0})", msgID));
        return true;
      }
      else if(msgID == "RunWorkerCompleted") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandDebugToolDumpPtnData : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendDebugToolDumpPatternMessage(msgID, data as DebugToolDumpPatternMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "DumpPattern") {
        //Trace.WriteLine(string.Format("YtPrairieDbg: <wcf_server> IsMyResponsibility({0})", msgID));
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandDebugToolDumpTimData : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendDebugToolDumpTimingMessage(msgID, data as DebugToolDumpTimingMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "DumpTiming") {
        //Trace.WriteLine(string.Format("YtPrairieDbg: <wcf_server> IsMyResponsibility({0})", msgID));
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandDebugToolDumpAcLogData : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendDebugToolDumpAcLogMessage(msgID, data as DebugToolDumpAcLogMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "DumpAcLog") {
        //Trace.WriteLine(string.Format("YtPrairieDbg: <wcf_server> IsMyResponsibility({0})", msgID));
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandDebugToolDumpLa : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendDebugToolDumpLaMessage(msgID, data as DebugToolDumpLaMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "DumpLa") {
        //Trace.WriteLine(string.Format("YtPrairieDbg: <wcf_server> IsMyResponsibility({0})", msgID));
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandDebugToolDumpCapture : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendDebugToolDumpCaptureMessage(msgID, data as DebugToolDumpCaptureMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "DumpCapture") {
        //Trace.WriteLine(string.Format("YtPrairieDbg: <wcf_server> IsMyResponsibility({0})", msgID));
        return true;
      }
      else {
        return false;
      }
    }
  }

  #endregion

  #region Server Command Shmoo
  //Shmoo======================================
  class ServerCommandShmooIniInfo : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendShmooIniInfoMessage(msgID, data as ShmooIniInfoMessageArgs);
    }
    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "OpenWindow") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandShmooPlanInfo : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendShmooPlanInfoMessage(msgID, data as ShmooPlanInfoMessageArgs);
    }
    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "SyncPlan" || msgID == "SyncMacro" || msgID == "PlanTreeAddNode") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandShmooSiteInfo : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendShmooSiteInfoMessage(msgID, data as ShmooSiteInfoMessageArgs);
    }
    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "RunSites") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandShmooPinGroupTable : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendShmooPinGroupTableMessage(msgID, data as ShmooPinGroupTableMessageArgs);
    }
    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "PinGroupTable") {
        return true;
      }
      else {
        return false;
      }
    }
  }


  class ServerCommandShmooPFResult : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendShmooPFResultMessage(msgID, data as ShmooPFResultMessageArgs);
    }
    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "SitePF") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  #endregion
  class ServerCommandNormalMessage : ChainOfServerCommand<IFromServerToClientMessage>
  {
    internal override void DoExecute(IFromServerToClientMessage server, string msgID, object data) {
      server.SendMessage(msgID, data);
    }

    internal override bool IsMyResponsibility(string msgID) {
      return true;
    }
  }

  #region Server Command Duplex
  class ServerCommandDuplexPinGroup : ChainOfServerCommand<IDuplexCallbackMessage>
  {
    internal override void DoExecute(IDuplexCallbackMessage server, string msgID, object data) {
      server.PostPinGroupMessage(msgID, data as IOPinGroupMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "AddIOPinGroup" || msgID == "AddIOPwrGroup" || msgID == "GroupPinList") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandDuplexDrivenInfo : ChainOfServerCommand<IDuplexCallbackMessage>
  {
    internal override void DoExecute(IDuplexCallbackMessage server, string msgID, object data) {
      server.PostDrivenInfoMessage(msgID, data as DriverInfoMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "SetDrivenInfo" || msgID == "DriverData") {
        return true;
      }
      else {
        return false;
      }
    }
  }
 
  //Shmoo======================================
  class ServerCommandDuplexShmooIniInfo : ChainOfServerCommand<IDuplexCallbackMessage>
  {
    internal override void DoExecute(IDuplexCallbackMessage server, string msgID, object data) {
      server.PostShmooIniInfoMessage(msgID, data as ShmooIniInfoMessageArgs);
    }
    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "OpenWindow") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandDuplexShmooPlanInfo : ChainOfServerCommand<IDuplexCallbackMessage>
  {
    internal override void DoExecute(IDuplexCallbackMessage server, string msgID, object data) {
      server.PostShmooPlanInfoMessage(msgID, data as ShmooPlanInfoMessageArgs);
    }
    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "SyncPlan" || msgID == "SyncMacro" || msgID == "PlanTreeAddNode") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandDuplexShmooSiteInfo : ChainOfServerCommand<IDuplexCallbackMessage>
  {
    internal override void DoExecute(IDuplexCallbackMessage server, string msgID, object data) {
      server.PostShmooSiteInfoMessage(msgID, data as ShmooSiteInfoMessageArgs);
    }
    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "RunSites") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandDuplexShmooPinGroupTable : ChainOfServerCommand<IDuplexCallbackMessage>
  {
    internal override void DoExecute(IDuplexCallbackMessage server, string msgID, object data) {
      server.PostShmooPinGroupTableMessage(msgID, data as ShmooPinGroupTableMessageArgs);
    }
    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "PinGroupTable") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandDuplexShmooPFResult : ChainOfServerCommand<IDuplexCallbackMessage>
  {
    internal override void DoExecute(IDuplexCallbackMessage server, string msgID, object data) {
      server.PostShmooPFResultMessage(msgID, data as ShmooPFResultMessageArgs);
    }
    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "SitePF") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ServerCommandDuplexNormalMessage : ChainOfServerCommand<IDuplexCallbackMessage>
  {
    internal override void DoExecute(IDuplexCallbackMessage server, string msgID, object data) {
      server.PostMessage(msgID, data);
    }

    internal override bool IsMyResponsibility(string msgID) {
      return true;
    }
  }
  #endregion
  #region LogicAnalyzer
  class ServerCommandDuplexLAData : ChainOfServerCommand<IDuplexCallbackMessage>
  {
    internal override void DoExecute(IDuplexCallbackMessage server, string msgID, object data)
    {
      server.PostLADataMessage(msgID, data as LADataMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID)
    {
      if (msgID == "LAData")
      {
        return true;
      }
      else
      {
        return false;
      }
    }
  }
  class ServerCommandDuplexLATiming : ChainOfServerCommand<IDuplexCallbackMessage>
  {
    internal override void DoExecute(IDuplexCallbackMessage server, string msgID, object data)
    {
      server.PostLATimingMessage(msgID, data as LATimingMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID)
    {
      if (msgID == "LATiming")
      {
        return true;
      }
      else
      {
        return false;
      }
    }
  }

  class ServerCommandDuplexCollectionData : ChainOfServerCommand<IDuplexCallbackMessage>
  {
    internal override void DoExecute(IDuplexCallbackMessage server, string msgID, object data)
    {
      server.PostCollectionMessage(msgID, data as List<object>);
    }

    internal override bool IsMyResponsibility(string msgID)
    {
      if (msgID == "ACDebugInfo")
      {
        return true;
      }
      else
      {
        return false;
      }
    }
  }
  #endregion  
}
