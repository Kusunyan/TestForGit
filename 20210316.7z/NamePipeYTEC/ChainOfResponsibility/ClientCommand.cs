﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
  class ClientCommandFlowPre : ChainOfClientCommand<IFromClientToServerMessage>
  {
    internal override void DoExecute(IFromClientToServerMessage client, string clientID, string msgID, object data) {
      client.SendFlowPreMessage(clientID, msgID, data as FlowPreMessageArgs);
    }
    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "FlowPre") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ClientCommandFlowCondition : ChainOfClientCommand<IFromClientToServerMessage>
    {
    internal override void DoExecute(IFromClientToServerMessage client, string clientID, string msgID, object data) {
      client.SendFlowConditionMessage(clientID, msgID, data as FlowConditionMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "FlowCondition") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ClientCommandKernalUpdateVal : ChainOfClientCommand<IFromClientToServerMessage>
    {
    internal override void DoExecute(IFromClientToServerMessage client, string clientID, string msgID, object data) {
      client.SendKenralUpdateValMessage(clientID, msgID, data as KernalUpdateValMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "KernalUpdateVal") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ClientCommandReplaceDrivenInfo : ChainOfClientCommand<IFromClientToServerMessage>
    {
    internal override void DoExecute(IFromClientToServerMessage client, string clientID, string msgID, object data) {
      client.SendDrivenInfoMessage(clientID, msgID, data as DriverInfoMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      if (msgID == "ReplaceDrivenInfo") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ClientCommandDebugToolDumpPtnSet : ChainOfClientCommand<IFromClientToServerMessage>
    {
    internal override void DoExecute(IFromClientToServerMessage client, string clientID, string msgID, object data) {
      client.SendDebugToolDumpPatternMessage(clientID, msgID, data as DebugToolDumpPatternMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      //Trace.WriteLine(string.Format("YtPrairieDbg: <wcf_client> IsMyResponsibility({0})", msgID));
      if (msgID == "DumpPattern") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ClientCommandDebugToolDumpTimSet : ChainOfClientCommand<IFromClientToServerMessage>
  {
    internal override void DoExecute(IFromClientToServerMessage client, string clientID, string msgID, object data) {
      client.SendDebugToolDumpTimingMessage(clientID, msgID, data as DebugToolDumpTimingMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      //Trace.WriteLine(string.Format("YtPrairieDbg: <wcf_client> IsMyResponsibility({0})", msgID));
      if (msgID == "DumpTiming") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ClientCommandDebugToolDumpAcLog : ChainOfClientCommand<IFromClientToServerMessage>
  {
    internal override void DoExecute(IFromClientToServerMessage client, string clientID, string msgID, object data) {
      client.SendDebugToolDumpAcLogMessage(clientID, msgID, data as DebugToolDumpAcLogMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      //Trace.WriteLine(string.Format("YtPrairieDbg: <wcf_client> IsMyResponsibility({0})", msgID));
      if (msgID == "DumpAcLog") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ClientCommandDebugToolDumpLa : ChainOfClientCommand<IFromClientToServerMessage>
  {
    internal override void DoExecute(IFromClientToServerMessage client, string clientID, string msgID, object data) {
      client.SendDebugToolDumpLaMessage(clientID, msgID, data as DebugToolDumpLaMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      //Trace.WriteLine(string.Format("YtPrairieDbg: <wcf_client> IsMyResponsibility({0})", msgID));
      if (msgID == "DumpLa") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ClientCommandDebugToolDumpCapture : ChainOfClientCommand<IFromClientToServerMessage>
  {
    internal override void DoExecute(IFromClientToServerMessage client, string clientID, string msgID, object data) {
      client.SendDebugToolDumpCaptureMessage(clientID, msgID, data as DebugToolDumpCaptureMessageArgs);
    }

    internal override bool IsMyResponsibility(string msgID) {
      //Trace.WriteLine(string.Format("YtPrairieDbg: <wcf_client> IsMyResponsibility({0})", msgID));
      if (msgID == "DumpCapture") {
        return true;
      }
      else {
        return false;
      }
    }
  }
  class ClientCommandNormalMessage : ChainOfClientCommand<IFromClientToServerMessage>
    {
    internal override void DoExecute(IFromClientToServerMessage client, string clientID, string msgID, object data) {
      client.SendMessage(clientID, msgID, data);
    }

    internal override bool IsMyResponsibility(string msgID) {
      return true;
    }
  }
    #region Client Command Duplex

    class ClientCommandDuplexNormalMessage : ChainOfClientCommand<IDuplexServiceMessage>
    {
        internal override void DoExecute(IDuplexServiceMessage client, string clientID, string msgID, object data)
        {
            client.PostMessage(clientID, msgID, data);
        }

        internal override bool IsMyResponsibility(string msgID)
        {
            return true;
        }
    }
  class ClientCommandDuplexCollectionMessage : ChainOfClientCommand<IDuplexServiceMessage>
  {
    internal override void DoExecute(IDuplexServiceMessage client, string clientID, string msgID, object data)
    {
      client.PostCollectionMessage(clientID, msgID, data as List<object>);
    }

    internal override bool IsMyResponsibility(string msgID)
    {
      if (msgID == "MapLAToDataLog" )
      {
        return true;
      }
      else
      {
        return false;
      }
    }
  }
  #endregion

}
