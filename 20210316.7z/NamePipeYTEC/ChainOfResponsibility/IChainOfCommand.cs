﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NamePipeYTEC
{
    internal interface IChainOfServerCommand
   {
        IChainOfServerCommand NextCommand { set; }
       void Execute(IFromServerToClientMessage server,string msgID,Object data);
    }
    internal interface IChainOfClientCommand
    {
        IChainOfClientCommand NextCommand { set; }
        void Execute(IFromClientToServerMessage client, string clientID, string msgID, Object data);
    }

    internal abstract class ChainOfServerCommand<T>
    {
        private ChainOfServerCommand<T> _NextCommand = null;
        public ChainOfServerCommand<T> NextCommand
        {
            protected get
            {
                return _NextCommand;
            }
            set
            {
                _NextCommand = value;
            }
        }

        public void Execute(T server, string msgID, Object data)
        {
            if (IsMyResponsibility(msgID))
            {
                DoExecute(server, msgID, data);
            }
            else
            {
                if (NextCommand != null)
                {
                    NextCommand.Execute(server, msgID, data);
                }
                else
                {
                    throw new Exception($"{msgID} is not combined in the chain of ServerCommand");
                }
            }
        }

        internal abstract void DoExecute(T server, string msgID, object data);
        internal abstract bool IsMyResponsibility(string msgID);
    }

    public abstract class ChainOfClientCommand<T>
    {
        private ChainOfClientCommand<T> _NextCommand = null;
        public ChainOfClientCommand<T> NextCommand
        {
            protected get
            {
                return _NextCommand;
            }
            set
            {
                _NextCommand = value;
            }
        }
        
        public void Execute(T client, string clientID, string msgID, Object data)
        {
            if (IsMyResponsibility(msgID))
            {
                DoExecute(client, clientID, msgID, data);
            }
            else
            {
                if (NextCommand != null)
                {
                    NextCommand.Execute(client, clientID, msgID, data);
                }
                else
                {
                    throw new Exception($"{msgID} is not combined in the chain of ClientCommand");
                }           
            }
        }

        internal abstract void DoExecute(T client, string clientID, string msgID, object data);
        internal abstract bool IsMyResponsibility(string msgID);
    }
    
}
